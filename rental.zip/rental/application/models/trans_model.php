<?php
Class Trans_model extends CI_Model
{
	private $table_trans_1 = 'services';
	private $table_trans_2 = 'services_detail';
	private $private_key_1 = 'services_id';
	private $private_key_2 = 'detail_id';

	//START INVENTORY IN
	function trans_1_paged_list ($order_column='',$order_type='asc')
	{
        $session = $this->session->userdata('logged_in');
		$this->db->select('*');
		$this->db->from($this->table_trans_1);
        $this->db->join('kendaraan', $this->table_trans_1.'.kendaraan_id = kendaraan.id','inner');
        if($session['groupId']<>1 and $session['groupId']==3) {
            $this->db->where('created_by',$session['loginname']);
        }
		if (empty($order_column)||empty($order_type))
			$this->db->order_by($this->private_key_1,'asc');
		else
			$this->db->order_by($order_column,$order_type);
		return $this->db->get();
	}	
	function trans_1_count_all()
	{
		return $this->db->count_all($this->table_trans_1);
	}
	function trans_1_save($data_purchase)
	{
		$this->db->insert($this->table_trans_1,$data_purchase);
		return $this->db->insert_id();
	}
    function trans_1_save_detail($data_purchase)
    {
        $this->db->insert($this->table_trans_2,$data_purchase);
        return $this->db->insert_id();
    }
    function trans_1_update ($id, $data_purchase)
    {
        $this->db->where($this->private_key_1,$id);
        $this->db->update($this->table_trans_1,$data_purchase);
    }
    function trans_1_by_id($id)
	{
		$this->db->select('*');
		$this->db->from($this->table_trans_1);
        $this->db->join('kendaraan', $this->table_trans_1.'.kendaraan_id = kendaraan.id','inner');
		$this->db->where($this->private_key_1,$id);
		return $this->db->get();
	}
	function trans_1_detail($id)
    {
        $this->db->select('*');
        $this->db->from($this->table_trans_2);
        $this->db->join('sparepart', $this->table_trans_2.'.sparepart_id = sparepart.id','inner');
        $this->db->where($this->private_key_1,$id);
        return $this->db->get();
    }
    function trans_1_proses($id,$process)
	{
	    $date = date('Y-m-d');
	    if($process == 1) $this->db->set('tglapproval',$date,true);
	    else $this->db->set('tglservices',$date,true);
		$this->db->set('status_srv',$process,false);
		$this->db->where($this->private_key_1,$id);
		$this->db->update($this->table_trans_1);
	}
    //END INVENTORY IN
    function trans_1_report($keyword)
    {
        $this->db->select('*');
        $this->db->from($this->table_trans_1);
        $this->db->join($this->table_trans_2,$this->table_trans_1.'.services_id = '.$this->table_trans_2.'.services_id','inner');
        $this->db->where('tgl_services','');
        return $this->db->get();
    }
	#START UPDATE STOK
	function add_stok($id,$purchaseQty)
	{
		$this->db->set('stok_barang','stok_barang+'.$purchaseQty,false);
		$this->db->where('id',$id);
		$this->db->update('sparepart');
	}
	function update_stok($id,$orderQty)
	{
		$this->db->set('stok_barang','stok_barang-'.$orderQty,false);
		#$this->db->set('stokOut','stokOut+'.$orderQty,false);
        $this->db->where('id',$id);
        $this->db->update('sparepart');
	}
    function retur_stok($id,$orderQty)
    {
        $this->db->set('stokIn','stokIn-'.$orderQty,false);
        $this->db->set('stokOut','stokOut+'.$orderQty,false);
        $this->db->where('productId',$id);
        $this->db->update($this->table_product);
    }
	#END UPDATE STOK

    #UNTUK REPORT KENDARAN
    function report_kendaraan($start,$end)
    {
        $this->db->select('*');
        $this->db->from($this->table_trans_1);
        $this->db->join('kendaraan', $this->table_trans_1.'.kendaraan_id = kendaraan.id','inner');
        $this->db->group_start()->where('tglservices >= ',$start)->where('tglservices <=',$end)->group_end();
        return $this->db->get();
    }
    function report_services($start,$end)
    {
        $this->db->select('kendaraan_id, nopolisi');
        $this->db->from($this->table_trans_1);
        $this->db->join('kendaraan', $this->table_trans_1.'.kendaraan_id = kendaraan.id','inner');
        $this->db->group_start()->where('tgl_services >= ',$start)->where('tgl_services <=',$end)->group_end();
        $this->db->group_by('kendaraan_id, nopolisi');
        return $this->db->get();
    }
    function report_services_detail($start,$end)
    {
        $this->db->select('*');
        $this->db->from($this->table_trans_1);
        $this->db->join($this->table_trans_2,$this->table_trans_1.'.services_id = '.$this->table_trans_2.'.services_id','inner');
        $this->db->join('sparepart',$this->table_trans_2.'.sparepart_id = sparepart.id','inner');
        $this->db->group_start()->where('tgl_services >= ',$start)->where('tgl_services <=',$end)->group_end();
        return $this->db->get();
    }
    function report_monthly($start,$end)
    {
        $this->db->select('kendaraan_id , nopolisi');
        $this->db->from($this->table_trans_1);
        $this->db->join('kendaraan', $this->table_trans_1.'.kendaraan_id = kendaraan.id','inner');
        $this->db->group_start()->where('tgl_services >= ',$start)->where('tgl_services <=',$end)->group_end();
        $this->db->group_by('kendaraan_id, nopolisi');
        return $this->db->get();
    }
    function report_monthly_detail($start,$end)
    {
        $this->db->select('*');
        $this->db->from($this->table_trans_1);
        $this->db->join($this->table_trans_2,$this->table_trans_1.'.services_id = '.$this->table_trans_2.'.services_id','inner');
        $this->db->join('sparepart',$this->table_trans_2.'.sparepart_id = sparepart.id','inner');
        $this->db->group_start()->where('tgl_services >= ',$start)->where('tgl_services <=',$end)->group_end();
        return $this->db->get();
    }
    function sum_transaksi()
    {
        $this->db->select('avg(jumlah*harga) as total');
        $this->db->from($this->table_trans_1);
        $this->db->join($this->table_trans_2,$this->table_trans_1.'.services_id = '.$this->table_trans_2.'.services_id','inner');
        $this->db->join('sparepart',$this->table_trans_2.'.sparepart_id = sparepart.id','inner');
        return $this->db->get()->row()->total;
    }
    function top_expense()
    {
        $this->db->select('nopolisi, kendaraan.merk,sum(jumlah*harga) as total');
        $this->db->from($this->table_trans_1);
        $this->db->join($this->table_trans_2,$this->table_trans_1.'.services_id = '.$this->table_trans_2.'.services_id','inner');
        $this->db->join('sparepart',$this->table_trans_2.'.sparepart_id = sparepart.id','inner');
        $this->db->join('kendaraan',$this->table_trans_1.'.kendaraan_id = kendaraan.id','inner');
        $this->db->group_by('nopolisi, kendaraan.merk');
        return $this->db->get();
    }
    function top_sparepart()
    {
        $this->db->select('nama,sum(jumlah*harga) as total');
        $this->db->from($this->table_trans_1);
        $this->db->join($this->table_trans_2,$this->table_trans_1.'.services_id = '.$this->table_trans_2.'.services_id','inner');
        $this->db->join('sparepart',$this->table_trans_2.'.sparepart_id = sparepart.id','inner');
        $this->db->group_by('nama');
        return $this->db->get();
    }
    function annual_services()
    {
        $this->db->select("date_format(tgl_services,'%b') as bulan, date_format(tgl_services,'%m') as x, count(services_id) as total");
        $this->db->from($this->table_trans_1);
        $this->db->group_start()->where('tgl_services >= ','2017-01-01')->where('tgl_services <=','2017-12-31')->group_end();
        $this->db->group_by("date_format(tgl_services,'%b') ,date_format(tgl_services,'%m')");
        $this->db->order_by('x','asc');
        return $this->db->get();
    }
}
?>