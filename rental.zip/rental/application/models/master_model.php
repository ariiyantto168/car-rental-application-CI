<?php 
Class Master_model extends CI_Model
{
	private $table_master_1 = 'tipe';
    private $master_1_pk = 'id';
    private $table_master_2 = 'sparepart';
    private $master_2_pk = 'id';
    private $table_master_3 = 'kendaraan';
    private $master_3_pk = 'id';
    private $table_master_4 = "tipe";
    private $table_master_5 = "merk";

    private $table_reftype = 'sys_reftype';
	//START MASTER 1
	function master_1_get_paged_list($limit=10,$offset=0, $order_column='',$order_type='asc')
	{
        if (empty($order_column)||empty($order_type))
            $this->db->order_by($this->master_1_pk,'asc');
        else
            $this->db->order_by($order_column,$order_type);
        return $this->db->get($this->table_master_1,$limit,$offset);
	}
	function master_1_count_all($name="")
	{
		$this->db->select('*');
		$this->db->from($this->table_master_1);
		if (!empty($name))
		{
			$this->db->like('name',$name);
		}
		$data = $this->db->get();
		return $data->num_rows();
	}
	function master_1_get_by_id ($id)
	{
		$this->db->where('id',$id);
		$this->db->from($this->table_master_1);
		return $this->db->get();
	}
	function master_1_save($event)
	{
		$this->db->insert($this->table_master_1,$event);
		return $this->db->insert_id();
	}
	function master_1_update ($id, $event)
	{
		$this->db->where('id',$id);
		$this->db->update($this->table_master_1,$event);
	}
	function master_1_delete ($id)
	{
		$this->db->where('id',$id);
		$this->db->delete($this->table_master_1);
	}
	//LIST AUTOCOMPLETE EVENT
	function master_1_lookup ()
	{
        $this->db->order_by($this->master_1_pk,'asc');
        $hasil = $this->db->get($this->table_master_1);
        foreach ($hasil->result_array() as $list)
        {
            $result[] = "Select ...";
            $result[$list[$this->master_1_pk]] = $list['name'];
        }
        return $result;
	}
	function master_1_list()
    {
        $eventlist = array();
        $this->db->order_by($this->master_1_pk,'asc');
        $result = $this->db->get($this->table_master_1);
        foreach ($result->result() as $list)
        {
            $eventlist[] = array('id' =>$list->id,'name'=>$list->name);
        }
        return $eventlist;
    }
    //untuk get list LI
    function master_1_services($master_1_id)
    {
        $this->db->select($this->table_master_3.'.id, name, description, price ');
        $this->db->from($this->table_master_3);
        $this->db->join($this->table_master_2,$this->table_master_3.'.services_id = '.$this->table_master_2.'.'.$this->master_2_pk,'inner');
        $this->db->where('event_id',$master_1_id);
        $this->db->order_by($this->master_3_pk,'asc');
        $result = $this->db->get();
        foreach ($result->result() as $list) {
            echo "<li>".$list->name."</li>";
        }

    }
    function master_1_srvbooking($master_1_id)
    {
        $this->db->select($this->table_master_3.'.id, name, description, price ');
        $this->db->from($this->table_master_3);
        $this->db->join($this->table_master_2,$this->table_master_3.'.services_id = '.$this->table_master_2.'.'.$this->master_2_pk,'inner');
        $this->db->where('event_id',$master_1_id);
        $this->db->order_by($this->master_3_pk,'asc');
        return $this->db->get();
    }
    function sum_srvcharge($master_1_id){
        $this->db->select_sum('price');
        $this->db->from($this->table_master_3);
        $this->db->where('event_id',$master_1_id);
        $result = $this->db->get();
        $nilai = $result->first_row();

        echo number_format($nilai->price);
    }


	//END MASTER EVENT

    //START MASTER SERVICES
    function master_2_get_paged_list($limit=10,$offset=0, $order_column='',$order_type='asc')
    {
        if (empty($order_column)||empty($order_type))
            $this->db->order_by($this->master_2_pk,'asc');
        else
            $this->db->order_by($order_column,$order_type);
        return $this->db->get($this->table_master_2,$limit,$offset);
    }
    function master_2_count_all($name="")
    {
        $this->db->select('*');
        $this->db->from($this->table_master_2);
        if (!empty($name))
        {
            $this->db->like('name',$name);
        }
        $data = $this->db->get();
        return $data->num_rows();
    }
    function master_2_get_by_id ($id)
    {
        $this->db->where('id',$id);
        $this->db->from($this->table_master_2);
        return $this->db->get();
    }
    function master_2_save($services)
    {
        $this->db->insert($this->table_master_2,$services);
        return $this->db->insert_id();
    }
    function master_2_update ($id, $services)
    {
        $this->db->where('id',$id);
        $this->db->update($this->table_master_2,$services);
    }
    function master_2_delete ($id)
    {
        $this->db->where('id',$id);
        $this->db->delete($this->table_master_2);
    }
    //LIST AUTOCOMPLETE SERVICES
    function master_2_lookup ()
    {
        $this->db->order_by($this->master_2_pk,'asc');
        $hasil = $this->db->get($this->table_master_2);
        foreach ($hasil->result_array() as $list)
        {
            $result[] = "Select ...";
            $result[$list[$this->master_2_pk]] = $list['name'];
        }
        return $result;
    }
    //LIST AUTOCOMPLETE SERVICES
    function master_2_select ()
    {
        $this->db->order_by($this->master_2_pk,'asc');
        return $this->db->get($this->table_master_2);
    }
    //END MASTER SERVICES
    //START SERVICES CHARGES
    function master_3_get_paged_list($limit=10,$offset=0, $order_column='',$order_type='asc')
    {
        $this->db->select($this->table_master_3.'.'.$this->master_3_pk.',kode, tahun, nopolisi, status,merk,  '.
            $this->table_master_4.'.nama as tipe');
        $this->db->from($this->table_master_3);
        $this->db->join($this->table_master_4, $this->table_master_3.'.tipe = '.$this->table_master_4.'.id','inner');
        if (empty($order_column)||empty($order_type))
            $this->db->order_by($this->master_3_pk,'asc');
        else
            $this->db->order_by($order_column,$order_type);
        $this->db->limit($limit,$offset);
        return $this->db->get();
    }
    function master_3_count_all($name="")
    {
        $this->db->select('*');
        $this->db->from($this->table_master_3);
        if (!empty($name))
        {
            $this->db->like('kode',$name);
        }
        $data = $this->db->get();
        return $data->num_rows();
    }
    function master_3_get_by_id ($id)
    {
        $this->db->where('id',$id);
        $this->db->from($this->table_master_3);
        return $this->db->get();
    }
    function master_3_save($charges)
    {
        $this->db->insert($this->table_master_3,$charges);
        return $this->db->insert_id();
    }
    function master_3_update ($id, $charges)
    {
        $this->db->where('id',$id);
        $this->db->update($this->table_master_3,$charges);
    }
    function master_3_delete ($id)
    {
        $this->db->where('id',$id);
        $this->db->delete($this->table_master_3);
    }
    //LIST AUTOCOMPLETE SERVICES
    function master_3_lookup ($keyword)
    {
        $this->db->select('id,kode, nopolisi');
        $this->db->from($this->table_master_3);
        $this->db->where('status',2);
        $this->db->like('kode',$keyword,'after');
        return $this->db->get();

        //return $query->result();
    }
    function master_3_listall()
    {
        $this->db->order_by($this->master_3_pk,'asc');
        return $this->db->get($this->table_master_3);
    }
    //END SERVICES CHARGES

    //START DATA MASTER
    function master_4_lookup()
    {
        $this->db->order_by('id','asc');
        $hasil = $this->db->get($this->table_master_4);
        foreach ($hasil->result_array() as $list)
        {
            $result[] = "Select ...";
            $result[$list['id']] = $list['nama'];
        }
        return $result;
    }
    function master_5_lookup()
    {
        $this->db->order_by('id','asc');
        $hasil = $this->db->get($this->table_master_5);
        foreach ($hasil->result_array() as $list)
        {
            $result[] = "Select ...";
            $result[$list['id']] = $list['nama'];
        }
        return $result;
    }
    //END DATA MASTER
}
?>