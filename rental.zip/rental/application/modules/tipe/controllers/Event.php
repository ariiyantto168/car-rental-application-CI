<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
#session_start(); //we need to call PHP's session object to access it through CI
class Event extends CI_Controller {
	
	private $limit = 25;
	function __construct()
	{
	   parent::__construct();
        $this->load->model(Master_model::class);
        $this->master_model = new Master_model();
		$this->load->helper('form');
	   	$this->load->library('pagination');
	}
	function index($offset=0, $order_column='id', $order_type='asc')
	{
		if($this->session->userdata('logged_in'))
		{
			if (!$offset) $offset=0;
			if (!$order_column) $order_column = 'id';
			if (!$order_type) $order_type = 'asc';
		
			$data['result'] = $this->master_model->event_get_paged_list($this->limit, $offset, $order_column, $order_type);
		
			$config['base_url']=site_url('event/index/');
			$config['total_rows']=$this->master_model->event_count_all();
			//$config['per_page']=$this->limit;
			$config['uri_segment']='3';
			$this->pagination->initialize($config);
			$data['paginator']=$this->pagination->create_links();
		
			//table data
			$this->template->set('title','Event');
			$this->template->load('cpanel/template','eventList',$data);
		}
		else
		{
			//If no session, redirect to login page
			redirect('login', 'refresh');
		}
	}
	function create()
	{
		$user = $this->session->userdata('logged_in');
		if($this->input->post('action')){
			
			$data_event = array('name' => $this->input->post('eventName'));
			$this->master_model->event_save($data_event);
			
			//redirect
			redirect('event/index/');
		}
		// load view
		$this->template->set('title','Event :: Add Event');
		$this->template->load('cpanel/template','eventAddUpdate');
	}
	function update($id)
	{
		$user = $this->session->userdata('logged_in');
		$data['detail'] = $this->master_model->event_get_by_id($id)->row();

		if($this->input->post('action')){
            $data_event = array('name' => $this->input->post('eventName'));
            $this->master_model->event_update($id,$data_event);
			
			//redirect
			redirect('event/index/');
		}
        // load view
        $this->template->set('title','Event :: Update Event');
        $this->template->load('cpanel/template','eventAddUpdate',$data);
	}
	function delete ($id)
	{
		$this->master_model->event_delete($id);
		redirect('event/index/', 'refresh');
	}
}
?>