<script>
    $(document).ready(function() {
        $('#dataTables-user').DataTable({
                responsive: true
        });
    });
</script>
<div class="row">
	<div class="col-lg-12">
    	<div class="panel panel-default">
    	<div class="panel-heading"><a href="<?php echo base_url();?>user">User</a> - <a href="<?php echo base_url();?>user/create"><img src="<?php echo base_url();?>assets/images/new.png" alt="Create" border="0" title="Create" /></a></div>
		<div class="panel-body">
            <div class="dataTable_wrapper">
            	<table class="table table-striped table-bordered table-hover" id="dataTables-user">
            	<thead>
					<tr>
					<th>No</th>
					<th>Loginname</th>
					<th>Last Login Date</th>
                    <th>Status</th>
					<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $urut=1; foreach ($result->result_array() as $list) { ?>
					<tr>
					<td><?php echo $urut++ ?></td>
				    <td><?php echo $list['loginname'] ?></td>
				    <td><?php echo $list['lastlogindate'] ?></td>
                    <td><?php if($list['status']==1) { echo "Active"; } else { echo "InActive"; } ?></td>
				    <td>
                    <a href="<?php echo base_url();?>user/update/<?php echo $list['id'] ?>"><img src="<?php echo base_url();?>assets/images/edit.png" alt="Edit" border="0" title="Edit" /></a>
                    <?php if($list['status']==1) { ?>
                    <a OnClick="return confirm('Are you want inactive this users?');" href="<?php echo base_url();?>user/process/<?php echo $list['id'] ?>/2"><img src="<?php echo base_url();?>assets/images/delete.png" alt="InActive" border="0" title="InActive" /></a>
                    <?php } else { ?>
                    <a onclick="return confirm('Are you sure want to re-active this users ?');" href="<?php echo base_url();?>user/process/<?php echo $list['id'] ?>/1"><img src="<?php echo base_url();?>assets/images/checked.png" alt="Active" border="0" title="Active" /></a>
                    <?php } ?> 
                    </td>							
					</tr>
				<?php } ?>
				</tbody>
            	</table>
            </div>
        </div>
		</div>
	</div>
</div>