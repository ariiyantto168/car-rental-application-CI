<script type="text/javascript">
$(document).ready(function(){
	$("#btnPrint").on("click", function () {
		var divContents = $("#divPrint").html();
		var printWindow = window.open('', '', 'height=400,width=800');
		printWindow.document.write('<html><head><title>Cetak Nota</title>');
		printWindow.document.write('</head><link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" /><body >');
		printWindow.document.write(divContents);
		printWindow.document.write('</body></html>');
		printWindow.document.close();
		printWindow.print();
	});
	$("#dateperiod").daterangepicker();
});
</script>
<div class="row">
	<div class="col-lg-12">
    	<div class="panel panel-default">
    	<div class="panel-heading">Report Replacement</div>
		<div class="panel-body">
		<div class="row">
        <!-- AREA FORM -->
    	<div class="col-md-6">
    		<form class="form-horizontal" method="post" id="report_detail" name="report_detail">
		       <div class="form-group">
                <label class="col-sm-4 control-label">Date Period</label>
                <div class="col-sm-8">
                       <div class="input-group">
                          <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                          </div>
                          <input type="text" name="dateperiod" class="form-control pull-right" id="dateperiod" readonly="readonly">
                        </div>
                  </div>
            </div>
              <div class="form-group">
              <label class="col-sm-4 control-label"></label>
                <div class="col-sm-8">                    
                <input type="submit" name="action" value="View Report" class="btn btn-primary" />
                <input type="button" value="Print" class="btn btn-primary" id="btnPrint" />
               </div>
              </div>
              <!-- /.form group -->
		</form>
        </div>
        <!-- AREA FORM -->
        <? if($result) { ?>
        <!-- AREA RESULT -->
        <div class="col-md-8" id="divPrint">
		<div class="form-group">
                <label class="col-sm-4 control-label">Date Period : </label>
                <label class="col-sm-8 control-label"><? echo $startdate . " - ".$enddate ?></label>
              </div>
            <!-- iCheck -->
			<?php foreach($result->result_array() as $hasil) { ?>
            <div class="form-group">
              <table width="50%" class="table table-striped table-bordered table-hover" id="dataTables-example">
              	<thead>
                    <tr>
                        <th colspan="6">Police Number : <?php echo $hasil['nopolisi'] ?></th>
                     </tr>
                 </thead>
                <thead>
                    <tr>
                        <th>Date Services</th>
                        <th>Sparepart</th>
                        <th>Technician</th>
                     </tr>
                </thead>
                <tbody>
                 <?php foreach($detail->result_array() as $data) { 
					if($hasil['kendaraan_id'] == $data['kendaraan_id']) { ?>
                    <tr>
                        <td><?php echo $data['tgl_services'] ?></td>
                        <td><?php echo $data['nama'] ?></td>
                        <td><?php echo $data['created_by'] ?></td>
                    </tr>
                    <?php } } ?>
                </tbody>
            </table>
          </div>
          <?php } ?>
        </div>
        </div>
        <!-- AREA RESULT-->
        <?php } ?>
        </div>            
        </div>
		</div>
	</div>
</div>