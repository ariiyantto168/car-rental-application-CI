<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
Class Report extends CI_Controller{
	
	private $limit = 10;
	function __construct()
	{
		parent::__construct();
		$this->load->model('trans_model');
		$this->load->library('pagination');
	}
	function lookup(){
        $keyword = $this->input->post('term');
        $data['response'] = 'false';
        $data_lookup = $this->trnorder_model->trn_lookup($keyword);
        $query = $data_lookup->result();

        if(!empty($query) ) {
            $data['response'] = 'true';
            $data['message'] = array();

            foreach($query as $row)
            {
                $data['message'][] = array('label'=>$row->ticketId,'id'=>$row->orderId,'value'=>$row->ticketId,'orderItemId'=>$row->orderItemId,
                    'orderqty'=>$row->orderQty,'custname'=>$row->name, 'address'=>$row->address, 'productName'=>$row->ProductName,'pcode'=>$row->ProductCode);
            }
        }
        echo json_encode($data);
    }
    function kendaraan()
    {
        if($this->input->post('action'))
        {
            $date = explode(" - ",$this->input->post('dateperiod'));
            $data['startdate'] = date_create($date[0])->format('d/M/Y');
            $data['enddate'] = date_create($date[1])->format('d/M/Y');
            $data['result'] = $this->trans_model->report_kendaraan($data['startdate'],$data['enddate']);

        } else $data['result'] = '';
        $this->template->set('title','Report :: Kendaraan Maintenance');
        $this->template->load('cpanel/template','rpt_kendaraan',$data);
    }
    function monthly()
    {
        if($this->input->post('action'))
        {
            $date = explode(" - ",$this->input->post('dateperiod'));
            $startdate = date_create($date[0])->format('Y-m-d');
            $enddate = date_create($date[1])->format('Y-m-d');

            $data['startdate'] = date_create($date[0])->format('d/M/Y');
            $data['enddate'] = date_create($date[1])->format('d/M/Y');
            $data['result'] = $this->trans_model->report_monthly($startdate,$enddate);
            $data['detail'] = $this->trans_model->report_monthly_detail($startdate,$enddate);


        } else $data['result'] = '';
        $this->template->set('title','Report :: Report Replacement');
        $this->template->load('cpanel/template','rpt_monthly',$data);
    }
    function services()
    {
        if($this->input->post('action'))
        {
            $date = explode(" - ",$this->input->post('dateperiod'));
            $startdate = date_create($date[0])->format('Y-m-d');
            $enddate = date_create($date[1])->format('Y-m-d');
            $data['startdate'] = date_create($date[0])->format('d/M/Y');
            $data['enddate'] = date_create($date[1])->format('d/M/Y');

            $data['result']  = $this->trans_model->report_services($startdate,$enddate);
            $data['detail'] = $this->trans_model->report_services_detail($startdate,$enddate);


        } else $data['result'] = '';
        $this->template->set('title','Report :: History Services');
        $this->template->load('cpanel/template','rpt_services',$data);
    }

}