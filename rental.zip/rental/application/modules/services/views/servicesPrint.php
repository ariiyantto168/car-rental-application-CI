<script src="<? echo base_url(); ?>assets/js/jquery.validate.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.ui.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
<div class="col-lg-12">
<div class="panel panel-default">
	<div class="panel-heading">Detail Kendaraaan Maintenance</div>
	<div class="panel-body">
    <div class="row">
    	<div class="col-md-6">
        <form method="post" class="form-horizontal" id="srv_form" name="srv_form" enctype="multipart/form-data">
		<input type="hidden" name="id" value="<? echo $detail->services_id ?>" />
        <div class="form-group">
        <label class="col-sm-4 control-label">Tanggal Services</label>
            <div class="col-sm-8"><? echo $detail->tgl_services ?></div>
        </div>
        <div class="form-group">
        <label class="col-sm-4 control-label">Kode Kendaraan</label>
        	<div class="col-sm-3">
                <? echo $detail->kode ?>
             </div>
             <div class="col-sm-5">
                <? echo $detail->nopolisi ?>
            </div>
        </div>
        <div class="form-group">
        <label class="col-sm-2 control-label"></label>
        <div class="col-sm-10">
        <div class="table-responsive table-bordered">
        <table class="table" id="tblProduk">
            <thead>
                <tr>
                    <th width="80%">Sparepart Name</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
        <tbody>
        	<?php foreach($result->result_array() as $dtl) { ?>
          	<tr>
            	<td><? echo $dtl['nama'] ?></td>
                <td><? echo $dtl['jumlah'] ?></td>
                <td><? echo number_format($dtl['harga']) ?></td>
                <td><? echo number_format($dtl['jumlah'] * $dtl['harga'])  ?></td>
          	</tr>
        	<?php } ?>
        </tbody>
        </table>
        </div>
        </div>
        </div>
		<div class="form-group">
        <label class="col-sm-2 control-label"></label>
        <div class="col-sm-10">
        	<input type="button" value="Print" class="btn btn-success" onclick="" />
            <input type="button" value="Back" class="btn btn-primary" onclick="document.location.replace('<?php echo base_url();?>services');" />
            </div>
        </div>
        </form>
        </div>
    </div>
    </div>
</div>                       
</div>
