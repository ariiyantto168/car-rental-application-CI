<? 	$session = $this->session->userdata('logged_in'); ?>
<script src="<? echo base_url(); ?>assets/js/jquery.validate.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.ui.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
<script type="text/javascript">
$(document).ready(function()
{
	$("#btnPrint").on("click", function () {
		var divContents = $("#divPrint").html();
		var printWindow = window.open('', '', 'height=400,width=800');
		printWindow.document.write('<html><head><title>Cetak Nota</title>');
		printWindow.document.write('</head><link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" /><body >');
		printWindow.document.write(divContents);
		printWindow.document.write('</body></html>');
		printWindow.document.close();
		printWindow.print();
	});
	$( "#srv_form" ).validate({
	 rules:{
		 code:{required:true}
		 }
 	});
	$("#kode").autocomplete({
      minLength: 1,
      source:
        function(req, add ){
          $.ajax({
            url: "<?php echo base_url(); ?>kendaraan/lookup",
            dataType: 'json',
            type: 'POST',
            data: req,
            success: function(data){
              if(data.response =='true'){
			  	add(data.message);
              }
            }
          });
        },
		select:function (event,ui) {
			$("#kend_id").val(ui.item.id);
			$("#kode").val(ui.item.code);
			$("#name").val(ui.item.name);
		}
	});
});
</script>
<?php if ($_SERVER['PATH_INFO'] == "/services/create") { ?>
<script type="text/javascript">
$(document).ready(function(){
	var i=0;
	$("#add_row").click(function(){
     $('#addr'+i).html("<td><select id='sparepart_id"+i+"' name='sparepart_id["+i+"]' class='form-control'><option value=''>Pilih Sparepart</option><? foreach($list->result_array() as $result) { ?><option value='<? echo $result['id'] ?>'><? echo $result['nama'] ?></option><? } ?></select></td><td><input id='merk"+i+"' name='merk["+i+"]' type='text' class='form-control');' /></td><td><input id='jumlah"+i+"' maxlength=3 name='jumlah["+i+"]' type='text' class='form-control');' /></td>");
     $('#tblProduk').append('<tr id="addr'+(i+1)+'"></tr>');    
     	var $tblitem = $("#tblProduk tbody tr");	     
     i++;
 	});
});
</script>
<div class="col-lg-12">
<div class="panel panel-default">
	<div class="panel-heading">Add Kendaraaan Maintenance</div>
	<div class="panel-body">
    <div class="row">
    	<div class="col-md-6">
        <form method="post" class="form-horizontal" id="srv_form" name="srv_form" enctype="multipart/form-data">
        <div class="form-group">
        <label class="col-sm-4 control-label">Tanggal Services</label>
            <div class="col-sm-8">
                <input id="tgl_services" name="tgl_services" type="text" maxlength="10" readonly="readonly" class="form-control" value="<? echo date('Y-m-d'); ?>" />
            </div>
        </div>
        <div class="form-group">
        <label class="col-sm-4 control-label">Kode Kendaraan</label>
        	<div class="col-sm-8">
                <select id="kend_id" name="kend_id" class="form-control">
                <option value="">Pilih Kendaraan</option>
                <? foreach($kendaraan->result_array() as $j) { ?>
                	<option value="<?php echo $j['id'] ?>"><?php echo $j['kode']." - ".$j['nopolisi'] ?></option>
                <?php } ?>
                </select>
              </div>
        </div>
        <div class="form-group">
        <label class="col-sm-4 control-label">Kilometer</label>
        	<div class="col-sm-8">
                <input id="kilometer" name="kilometer" type="text" maxlength="20" class="form-control" value="" />
             </div>
        </div>
        <div class="form-group">
        <label class="col-sm-2 control-label"></label>
        <div class="col-sm-10">
        <div class="table-responsive table-bordered">
        <table class="table" id="tblProduk">
            <thead>
                <tr>
                    <th width="45%">Sparepart Name</th>
                    <th width="40%">Merk</th>
                    <th>Qty</th>
                </tr>
            </thead>
        <tbody>
          <tr id="addr0"></tr>
        
        </tbody>
        </table>
        </div>
        </div>
        </div>
		<div class="form-group">
        <label class="col-sm-2 control-label"></label>
        <div class="col-sm-10">
        	<input type="button" id="add_row" class="btn btn-primary pull-left" value="Add Row">&nbsp;
            <input type="submit" name="action" value="Save" class="btn btn-primary" />
            <input type="button" value="Cancel" class="btn btn-primary" onclick="document.location.replace('<?php echo base_url();?>services');" />
            </div>
        </div>
        </form>
        </div>
    </div>
    </div>
</div>                       
</div>

<?php } elseif($_SERVER['PATH_INFO'] == "/services/update/$detail->services_id" && $detail->status_srv == 0) { ?>
<script type="text/javascript">
$(document).ready(function(){
	var i=0;
	$("#add_row").click(function(){
     $('#addr'+i).html("<td><select id='sparepart_id"+i+"' name='sparepart_id["+i+"]' class='form-control'><option value=''>Pilih Sparepart</option><? foreach($list->result_array() as $result) { ?><option value='<? echo $result['id'] ?>'><? echo $result['nama'] ?></option><? } ?></select></td><td><input id='merk"+i+"' name='merk["+i+"]' type='text' class='form-control');' /></td><td><input id='jumlah"+i+"' name='jumlah["+i+"]' type='text' class='form-control');' /></td>");
     $('#tblProduk').append('<tr id="addr'+(i+1)+'"></tr>');    
     	var $tblitem = $("#tblProduk tbody tr");	     
     i++;
 	});
});
</script>
<div class="col-lg-12">
<div class="panel panel-default">
	<div class="panel-heading">Update Kendaraaan Maintenance</div>
	<div class="panel-body">
    <div class="row">
    	<div class="col-md-6">
        <form method="post" class="form-horizontal" id="srv_form" name="srv_form" enctype="multipart/form-data">
		<input type="hidden" name="id" value="<? echo $detail->services_id ?>" />
        <div class="form-group">
        <label class="col-sm-4 control-label">Tanggal Services</label>
            <div class="col-sm-8">
                <input id="tgl_services" name="tgl_services" type="text" maxlength="10" readonly="readonly" class="form-control" value="<? echo date('Y-m-d'); ?>" />
            </div>
        </div>
        <div class="form-group">
        <label class="col-sm-4 control-label">Kode Kendaraan</label>
        	<div class="col-sm-3">
                <input id="kend_id" name="kend_id" type="hidden" value="<?php echo $detail->kendaraan_id ?>"/><input id="kode" name="kode" type="text" maxlength="20" class="form-control" value="<? echo $detail->kode ?>" />
             </div>
             <div class="col-sm-5">
                <input id="name" name="name" type="text" maxlength="20" disabled="disabled" readonly="readonly" class="form-control" value="<? echo $detail->nopolisi ?>" />
            </div>
        </div>
        <div class="form-group">
        <label class="col-sm-4 control-label">Kilometer</label>
        	<div class="col-sm-8">
                <input id="kilometer" name="kilometer" type="text" maxlength="20" class="form-control" value="<?php echo $detail->kilometer ?>" />
             </div>
        </div>
        <div class="form-group">
        <label class="col-sm-2 control-label"></label>
        <div class="col-sm-10">
        <div class="table-responsive table-bordered">
        <table class="table" id="tblProduk">
            <thead>
                <tr>
                    <th width="80%">Sparepart Name</th>
                    <th>Qty</th>
                </tr>
            </thead>
        <tbody>
          <tr id="addr0"></tr>
        
        </tbody>
        </table>
        </div>
        </div>
        </div>
		<div class="form-group">
        <label class="col-sm-2 control-label"></label>
        <div class="col-sm-10">
        	<input type="button" id="add_row" class="btn btn-primary pull-left" value="Add Row">&nbsp;
            <input type="submit" name="action" value="Update" class="btn btn-primary" />
            <input type="button" value="Cancel" class="btn btn-primary" onclick="document.location.replace('<?php echo base_url();?>services');" />
            </div>
        </div>
        </form>
        </div>
    </div>
    </div>
</div>                       
</div>
<?php } else { ?>
<div class="col-lg-12" id="divPrint">
<div class="panel panel-default">
	<div class="panel-heading">Detail Kendaraaan Maintenance</div>
	<div class="panel-body">
    <div class="row">
    	<div class="col-md-6">
        <form method="post" class="form-horizontal" id="srv_form" name="srv_form" enctype="multipart/form-data">
		<input type="hidden" name="id" value="<? echo $detail->services_id ?>" />
        <div class="form-group">
        <label class="col-sm-4 control-label">Tanggal Services</label>
            <div class="col-sm-8"><? echo $detail->tgl_services ?></div>
        </div>
        <div class="form-group">
        <label class="col-sm-4 control-label">Kode Kendaraan</label>
        	<div class="col-sm-3">
                <? echo $detail->kode ?>
             </div>
             <div class="col-sm-5">
                <? echo $detail->nopolisi ?>
            </div>
        </div>
        <div class="form-group">
        <label class="col-sm-4 control-label">Kilometer</label>
            <div class="col-sm-8"><? echo $detail->kilometer ?></div>
        </div>
        <div class="form-group">
        <label class="col-sm-2 control-label"></label>
            <div class="col-sm-10">
                <div class="table-responsive table-bordered">
                <table class="table" id="tblProduk">
                    <thead>
                        <tr>
                            <th width="40%">Sparepart Name</th>
                            <th>Merk</th>
                            <th>Qty</th>
                            <?php if($session['groupId'] <> 3) { ?>
                        	<th>Price</th>
                            <th>Total</th>
                            <?php } ?>
                        </tr>
                    </thead>
                <tbody>
                    <?php foreach($result->result_array() as $dtl) { ?>
                    <tr>
                        <td><? echo $dtl['nama'] ?></td>
                        <td><? echo $dtl['merk'] ?></td>
                        <td><? echo $dtl['jumlah'] ?></td>
                        <?php if($session['groupId'] <> 3) { ?>
                        <td><? echo number_format($dtl['harga']) ?></td>
                        <td><? echo number_format($dtl['jumlah'] * $dtl['harga'])  ?></td>
                       	<?php } ?>
                    </tr>
                    <?php } ?>
                </tbody>
                </table>
                </div>
            </div>
        </div>
		<div class="form-group">
        <label class="col-sm-2 control-label"></label>
        </div>
        </form>
        </div>
    </div>
    </div>
</div>                       
</div>
<div class="col-sm-10">
        	<input type="button" value="Print" class="btn btn-success" id="btnPrint" />
            <input type="button" value="Back" class="btn btn-primary" onclick="document.location.replace('<?php echo base_url();?>services');" />
		</div>
        
<?php } ?>
