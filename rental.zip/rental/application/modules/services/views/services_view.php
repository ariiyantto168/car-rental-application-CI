<? 	$session = $this->session->userdata('logged_in'); ?>
<script>
    $(document).ready(function() {
        $('#dataTables-invoice').DataTable({
                responsive: true
        });
    });
</script>
<div class="row">
	<div class="col-lg-12">
    	<div class="panel panel-default">
    	<div class="panel-heading"><a href="<?php echo base_url();?>services">Services</a><?php if($session['groupId'] <> 2) { ?> - <a href="<?php echo base_url();?>services/create"><img src="<?php echo base_url();?>assets/images/new.png" alt="Create" border="0" title="Create" /></a><?php } ?></div>
		<div class="panel-body">
            <div class="dataTable_wrapper">
            	<table class="table table-striped table-bordered table-hover" id="dataTables-invoice">
            	<thead>
					<tr>
					<th>No</th>
				    <th>Services ID#</th>
				    <th>Kode Kendaraan</th>
				    <th>Services Date</th>
				    <th>Status</th>
				    <th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $urut=1; foreach($listproduct->result_array() as $result) { ?>
					  <tr> 
					    <td><?php echo $urut; ?></td>
					    <td><?php echo $result['kode_services'] ?></td>
					    <td><?php echo $result['nopolisi'] ?></td>
					    <td><?php echo $result['tgl_services'] ?></td>
					    <td><?php if($result['status_srv']==1) { echo "Services"; } elseif ($result['status_srv']==2) { echo "Done"; } else { echo "Draft"; } ?></td>
					    <td>
                        <? if($session['groupId'] <> 3) { ?>
                        <? if($result['status_srv'] == 0) { ?><a onclick="return confirm('Are you sure want to process?');" href="<?php echo base_url();?>services/confirm/<?php echo $result['services_id'] ?>/1"><img src="<?php echo base_url();?>assets/images/checked.png" alt="Approve" border="0" title="Approve" /></a>
                        <? } } ?>
                        <? if($result['status_srv'] == 1 && $session['groupId']==3) { ?><a onclick="return confirm('Are you sure want to process?');" href="<?php echo base_url();?>services/confirm/<?php echo $result['services_id'] ?>/2"><img src="<?php echo base_url();?>assets/images/services.png" alt="Services" border="0" title="Services" /></a>
                        <? } ?>
                        </a> <a href="<?php echo base_url();?>services/detail/<?php echo $result['services_id'] ?>"><img src="<?php echo base_url();?>assets/images/review.png" alt="Review" border="0" title="Review" /></a></td>
					  </tr>
					  <?php $urut++; } ?>
				</tbody>
            	</table>
            </div>
        </div>
		</div>
	</div>
</div>