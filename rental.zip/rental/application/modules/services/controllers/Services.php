<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
#session_start(); //we need to call PHP's session object to access it through CI
class Services extends CI_Controller {

    private $limit = 10;
    function __construct()
	{
	   parent::__construct();
		$this->load->model('trans_model');
		$this->load->model('master_model');

		$this->load->helper('form');
        $this->load->library('pagination');
		$this->load->helper('number');
	}
	function index($order_column='services_id', $order_type='asc')
	{
	    if($this->session->userdata('logged_in'))
        {
            if (!$order_column) $order_column = 'services_id';
            if (!$order_type) $order_type = 'asc';

            $data['listproduct'] = $this->trans_model->trans_1_paged_list($order_column, $order_type);
            $config['base_url']=site_url('services/index/');
            $config['total_rows']=$this->trans_model->trans_1_count_all();
            //$config['per_page']=$this->limit;
            $config['uri_segment']='3';
            $this->pagination->initialize($config);
            $data['paginator']=$this->pagination->create_links();

            // load view
            $this->template->set('title','Maintenance :: List Kendaraaan Maintenance');
            $this->template->load('cpanel/template','services_view',$data);
        }
        else
        {
            redirect('login', 'refresh');
        }

	}
	function detail($id)
	{
		$data['detail'] = $this->trans_model->trans_1_by_id($id)->row();
        $data['result'] = $this->trans_model->trans_1_detail($id);

        #UPDATE VIEW
		#$this->trnorder_model->productView($id);

		// load view
		$this->template->set('title','Product :: View Product');
		$this->template->load('cpanel/template','servicesAddUpdate',$data);
	}
	function create()
	{
        if($this->session->userdata('logged_in')) {

            $user = $this->session->userdata('logged_in');
            $data['list'] = $this->master_model->master_2_select();
            $data['kendaraan'] = $this->master_model->master_3_listall();

            if ($this->input->post('action')) {
                #DATA ORDER
                $ticketId = mt_rand(111111, 999999); #NO TICKET ORDER
                $data_order = array('kode_services' => $ticketId,
                    'tgl_services' => $this->input->post('tgl_services'),
                    'kendaraan_id' => $this->input->post('kend_id'),'kilometer'=>$this->input->post('kilometer'),
                    'created_by' => $user['loginname']);
                $orderId = $this->trans_model->trans_1_save($data_order);
                #UPDATE STATUS KENDARAAN
                $this->master_model->master_3_update($this->input->post('kend_id'),array('status'=>1));
                #ADD DETAIL
                $count = count($this->input->post('sparepart_id'));
                for($i=0; $i<$count; $i++) {
                    $data_detail = array('services_id'=>$orderId,'sparepart_id'=>$_POST['sparepart_id'][$i],
                        'merk'=>$_POST['merk'][$i],'jumlah'=>$_POST['jumlah'][$i]);
                    $this->trans_model->trans_1_save_detail($data_detail);
                }

                redirect('services/index/');
            }
            // load view
            $this->template->set('title', 'Maintenance :: Create Kendaraaan Maintenance');
            $this->template->load('cpanel/template', 'servicesAddUpdate',$data);
        }
        else {
            redirect('login', 'refresh');
        }
	}
	function update($id)
    {
        if($this->session->userdata('logged_in')) {

            $user = $this->session->userdata('logged_in');
            $data['detail'] = $this->trans_model->trans_1_by_id($id)->row();
            $data['result'] = $this->trans_model->trans_1_detail($id);
            $data['list'] = $this->master_model->master_2_select();

            if ($this->input->post('action')) {
                #DATA ORDER
                $ticketId = mt_rand(111111, 999999); #NO TICKET ORDER
                $data_order = array('kode_services' => $ticketId,
                    'tgl_services' => $this->input->post('tgl_services'),
                    'kendaraan_id' => $this->input->post('kend_id'),'kilometer'=>$this->input->post('kilometer'),
                    'created_by' => $user['loginname']);
                $orderId = $this->trans_model->trans_1_save($data_order);
                #ADD DETAIL
                $count = count($this->input->post('sparepart_id'));
                for($i=0; $i<$count; $i++) {
                    $data_detail = array('services_id'=>$orderId,'sparepart_id'=>$_POST['sparepart_id'][$i],
                        'merk'=>$_POST['merk'][$i],'jumlah'=>$_POST['jumlah'][$i]);
                    $this->trans_model->trans_1_save_detail($data_detail);
                }

                redirect('services/index/');
            }
            // load view
            $this->template->set('title', 'Maintenance :: Update Kendaraaan Maintenance');
            $this->template->load('cpanel/template', 'servicesAddUpdate',$data);
        }
        else {
            redirect('login', 'refresh');
        }
    }
	function confirm($id,$status)
	{
		$data['detail'] = $this->trans_model->trans_1_by_id($id)->row();
        $this->trans_model->trans_1_proses($id,$status);
        if($status == 2){
            $this->master_model->master_3_update($data['detail']->kendaraan_id,array('status'=>2));
        }
        else if ($status == 1)
        {
            $result = $this->trans_model->trans_1_detail($id);
            foreach ($result->result_array() as $value)
            {
                $this->trans_model->update_stok($value['sparepart_id'],$value['jumlah']);
            }
        }

        redirect('services/index/');
        // load view
        $this->template->set('title','Maintenance :: List Kendaraaan Maintenance');
        $this->template->load('cpanel/template','services_view');
	}

	
}
?>