<?php

/**
 * Created by PhpStorm.
 * User: user
 * Date: 6/12/2017
 * Time: 11:31 PM
 */
defined('BASEPATH') OR exit('No direct script access allowed');
class Kendaraan extends CI_Controller
{
    private $limit = 10;
    function __construct()
    {
        parent::__construct();
        $this->load->model('master_model');
        $this->load->helper('form');
        $this->load->library('pagination');
    }

    function index($offset=0, $order_column='id', $order_type='asc')
    {
        if($this->session->userdata('logged_in'))
        {
            if (!$offset) $offset=0;
            if (!$order_column) $order_column = 'id';
            if (!$order_type) $order_type = 'asc';

            $data['result'] = $this->master_model->master_3_get_paged_list($this->limit, $offset, $order_column, $order_type);

            $config['base_url']=site_url('kendaraan/index/');
            $config['total_rows']=$this->master_model->master_3_count_all();
            //$config['per_page']=$this->limit;
            $config['uri_segment']='3';
            $this->pagination->initialize($config);
            $data['paginator']=$this->pagination->create_links();

            //table data
            $this->template->set('title','Kendaraan');
            $this->template->load('cpanel/template','kendaraanList',$data);
        }
        else
        {
            //If no session, redirect to login page
            redirect('login', 'refresh');
        }
    }
    function create()
    {
        $user = $this->session->userdata('logged_in');
        $data['gettipe'] = $this->master_model->master_4_lookup();
        if($this->input->post('action')){

            $data_charge = array('kode' => $this->input->post('kode'),
                'merk' => $this->input->post('merk'),
                'tipe' => $this->input->post('tipe'),
                'tahun' => $this->input->post('tahun'),
                'nopolisi' => $this->input->post('nopolisi'),
                'status' => '2');
            $this->master_model->master_3_save($data_charge);

            //redirect
            redirect('kendaraan/index/');
        }
        // load view
        $this->template->set('title','Kendaraan :: Add Kendaraan');
        $this->template->load('cpanel/template','kendaraanAddUpdate',$data);
    }
    function update($id)
    {
        $user = $this->session->userdata('logged_in');
        $data['gettipe'] = $this->master_model->master_4_lookup();
        $data['getmerk'] = $this->master_model->master_5_lookup();
        $data['detail'] = $this->master_model->master_3_get_by_id($id)->row();

        if($this->input->post('action')){
            $data_charge = array('kode' => $this->input->post('kode'),
                'merk' => $this->input->post('merk'),
                'tipe' => $this->input->post('tipe'),
                'tahun' => $this->input->post('tahun'),
                'nopolisi' => $this->input->post('nopolisi'),
                'status' => $this->input->post('status'));
            $this->master_model->master_3_update($id,$data_charge);

            //redirect
            redirect('kendaraan/index/');
        }
        // load view
        $this->template->set('title','Kendaraan :: Update Kendaraan');
        $this->template->load('cpanel/template','kendaraanAddUpdate',$data);
    }
    function delete ($id)
    {
        $this->master_model->master_3_delete($id);
        redirect('kendaraan/index/', 'refresh');
    }
    function lookup()
    {
        $keyword = $this->input->post('term');
        $data['response'] = 'false';
        $data_lookup = $this->master_model->master_3_lookup($keyword);
        $query = $data_lookup->result();

        if(!empty($query) ) {
            $data['response'] = 'true';
            $data['message'] = array();

            foreach($query as $row)
            {
                $data['message'][] = array('label'=>$row->kode,'id'=>$row->id,'value'=>$row->kode,
                    'name'=>$row->nopolisi,'kode'=>$row->kode);
            }
        }

        echo json_encode($data);
    }


}