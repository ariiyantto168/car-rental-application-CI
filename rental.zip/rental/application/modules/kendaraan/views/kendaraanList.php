<script>
    $(document).ready(function() {
        $('#dataTables-kendaraan').DataTable({
                responsive: true
        });
    });
</script>
<div class="row">
	<div class="col-lg-12">
    	<div class="panel panel-default">
    	<div class="panel-heading"><a href="<?php echo base_url();?>kendaraan">Vehicle</a> - <a href="<?php echo base_url();?>kendaraan/create"><img src="<?php echo base_url();?>assets/images/new.png" alt="Create" border="0" title="Create" /></a></div>
		<div class="panel-body">
            <div class="dataTable_wrapper">
            	<table class="table table-striped table-bordered table-hover" id="dataTables-kendaraan">
            	<thead>
					<tr>
					<th>No</th>
				    <th>Vehicle Code</th>
				    <th>Merk</th>
				    <th>Type</th>
                    <th>Police Number</th>
                    <th>Status</th>
				    <th>Action</th>
					</tr>
				</thead>
				<tbody>
				<?php $urut=1; foreach ($result->result_array() as $list) { ?>
				<tr>
					<td><?php echo $urut++ ?></td>
					<td><?php echo $list['kode'] ?></td>
                    <td><?php echo $list['merk'] ?></td>
                    <td><?php echo $list['tipe'] ?></td>
                    <td><?php echo $list['nopolisi'] ?></td>
                    <td><?php echo ($list['status']==1) ? 'Services' : 'Available'; ?></td>
					<td><a href="<?php echo base_url();?>kendaraan/update/<?php echo $list['id'] ?>"><img src="<?php echo base_url();?>assets/images/edit.png" alt="Edit" border="0" title="Edit" /></a> 
                    <?php if($list['status']!=1) { ?><a OnClick="return confirm('Are you delete this data?');" href="<?php echo base_url();?>kendaraan/delete/<?php echo $list['id'] ?>"><img src="<?php echo base_url();?>assets/images/delete.png" alt="Delete" border="0" title="Delete" /></a><?php } ?></td>
				</tr>
				<?php } ?>
				</tbody>
            	</table>
            </div>
        </div>
		</div>
	</div>
</div>