<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.ui.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.validate.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#charge_form").validate({
		rules: {
			kode: {
				required:true
			},
			tipe: {
				required:true
			},
			merk: {
				required:true
			},
			nopolisi: {
				required:true
			}
		}
	});
});
</script>
<?php if ($_SERVER['PATH_INFO'] == "/kendaraan/create") { ?>
<div class="col-lg-12">
<div class="panel panel-default">
	<div class="panel-heading">Add / Update</div>
	<div class="panel-body">
    <div class="row">
    	<div class="col-lg-6">
        <form method="post" id="charge_form" name="charge_form" enctype="multipart/form-data">
        <div class="form-group">
			<label>Vehicle Code</label>
			<input id="kode" name="kode" type="text" maxlength="20" class="form-control" value="" />
        </div>
        <div class="form-group">
            <label>Type</label>
                <?php $extra = array('class' => 'form-control'); echo form_dropdown("tipe",$gettipe,'',$extra) ?>
        </div>
        <div class="form-group">
            <label>Merk</label>
                <input id="merk" name="merk" type="text" maxlength="75" class="form-control" value="" />
        </div>
        <div class="form-group">
        	<label>Year</label>
			<?php $extra = array('class' => 'form-control'); echo form_dropdown("tahun",['','2015','2016','2017'],'',$extra) ?>
        </div>
        <div class="form-group">
			<label>Police Number</label>
			<input id="nopolisi" name="nopolisi" type="text" maxlength="10" class="form-control" value="" />
        </div>
        <div class="form-group">
            <input type="submit" name="action" value="Save" class="btn btn-primary" />
            <input type="button" value="Cancel" class="btn btn-primary" onclick="document.location.replace('<?php echo base_url();?>kendaraan');" />
        </div>
        </form>
        </div>
    </div>
    </div>
</div>                       
</div>

<?php } else { ?>

<div class="col-lg-12">
<div class="panel panel-default">
	<div class="panel-heading">Add / Update</div>
	<div class="panel-body">
    <div class="row">
    	<div class="col-lg-6">
        <form method="post" id="charge_form" name="charge_form" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<? echo $detail->id ?>" />
        <div class="form-group">
			<label>Kode Kendaraan</label>
			<input id="kode" name="kode" type="text" maxlength="20" class="form-control" value="<? echo $detail->kode ?>" />
        </div>
        <div class="form-group">
            <label>Tipe</label>
                <?php $extra = array('class' => 'form-control'); echo form_dropdown("tipe",$gettipe,$detail->tipe,$extra) ?>
        </div>
        <div class="form-group">
            <label>Merk</label>
                <input id="merk" name="merk" type="text" maxlength="75" class="form-control" value="<? echo $detail->merk ?>" />
        </div>
        <div class="form-group">
        	<label>Tahun</label>
			<?php $extra = array('class' => 'form-control'); echo form_dropdown("tahun",['','2015','2016','2017'],$detail->tahun,$extra) ?>
        </div>
        <div class="form-group">
			<label>No. Polisi</label>
			<input id="nopolisi" name="nopolisi" type="text" maxlength="10" class="form-control" value="<? echo $detail->nopolisi ?>" />
        </div>
        <div class="form-group">
			<label>Status</label>
			<?php $extra = array('class' => 'form-control','readonly'=>'readonly'); echo form_dropdown("status",['','Services','Available'],$detail->status,$extra) ?>
        </div>
        <div class="form-group">
            <input type="submit" name="action" value="Update" class="btn btn-primary" />
            <input type="button" value="Cancel" class="btn btn-primary" onclick="document.location.replace('<?php echo base_url();?>kendaraan');" />
        </div>
        </form>
        </div>
    </div>
    </div>
</div>                       
</div>

<?php } ?>
