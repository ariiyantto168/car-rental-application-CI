<link href="<?php echo base_url();?>/assets/css/morris.css" rel="stylesheet">
<script src="<?php echo base_url();?>/assets/js/raphael.min.js"></script>
<script src="<?php echo base_url();?>/assets/js/morris.min.js"></script>
<div class="row">
<div class="col-lg-3 col-md-6">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <div class="row">
                <div class="col-xs-3">
                    <i class="fa fa-comments fa-5x"></i>
                </div>
                <div class="col-xs-9 text-right">
                    <div class="huge"><?php echo $jumlah; ?></div>
                    <div>Total Kendaraan</div>
                </div>
            </div>
        </div>
        <a href="<? echo base_url(); ?>kendaraan/">
            <div class="panel-footer">
                <span class="pull-left">View Details</span>
                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                <div class="clearfix"></div>
            </div>
        </a>
    </div>
</div>
<div class="col-lg-3 col-md-6">
    <div class="panel panel-green">
        <div class="panel-heading">
            <div class="row">
                <div class="col-xs-3">
                    Rp.
                </div>
                <div class="col-xs-9 text-right">
                    <div class="huge"><?php echo number_format($total); ?></div>
                    <div>Total Expense (Avg)</div>
                </div>
            </div>
        </div>
        <a href="#">
            <div class="panel-footer">
                <span class="pull-left">&nbsp;</span>
                <span class="pull-right"></span>
                <div class="clearfix"></div>
            </div>
        </a>
    </div>
</div>
</div>
<!--kedua-->
<div class="row">
<!--exp-->
<div class="col-lg-6">
	<div class="panel panel-default">
        <div class="panel-heading">
            <i class="fa fa-bar-chart-o fa-fw"></i> Top 5 Expense Car Services
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>No Polisi</th>
                                    <th>Merk</th>
									<th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php $urut=1; foreach($list->result_array() as $daftar) { ?>
                                <tr>
                                    <td><?php echo $urut; ?></td>
                                    <td><?php echo $daftar['nopolisi']; ?></td>
                                    <td><?php echo $daftar['merk']; ?></td>
                                    <td>Rp. <?php echo number_format($daftar['total']); ?></td>
                                </tr>
                                <?php $urut++; } ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.table-responsive -->
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.panel-body -->
    </div>
</div>
<!--exp-->           
<!--spr-->
<div class="col-lg-6">
	<div class="panel panel-default">
        <div class="panel-heading">
            <i class="fa fa-bar-chart-o fa-fw"></i> Top 5 Sparepart
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Sparepart Name</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $urut=1; foreach($sparelist->result_array() as $daftar) { ?>
                                <tr>
                                    <td><?php echo $urut; ?></td>
                                    <td><?php echo $daftar['nama']; ?></td>
                                    <td>Rp. <?php echo number_format($daftar['total']); ?></td>
                                </tr>
                                <?php $urut++; } ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.table-responsive -->
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.panel-body -->
    </div>
</div>
<!--spr-->
</div>
<!--kedua-->
<!--ketiga-->
<div class="row">
    <div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading">
            <i class="fa fa-bar-chart-o fa-fw"></i> Annual Services Total
        </div>
        <!-- /.panel-heading -->
        <div class="panel-body">
            <div id="morris-bar-chart"></div>
        </div>
        <!-- /.panel-body -->
    </div>
    </div>
</div>
<!--ketiga-->
<script>
$(function() {
    Morris.Bar({
        element: 'morris-bar-chart',
        data: [
		 <?php foreach($annual->result_array() as $rpt) { ?>
		{
            y: '<?php echo $rpt['bulan']; ?>',
            a: <?php echo $rpt['total']; ?>
        },
		<?php } ?>],
        xkey: 'y',
        ykeys: ['a'],
        labels: ['Services'],
        hideHover: 'auto',
        resize: true
    });
    
});

</script>
