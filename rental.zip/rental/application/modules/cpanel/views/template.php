<?php  defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <meta charset="utf-8" />
    <title><?php echo $title;?></title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/font-awesome/4.5.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/metisMenu.min.css" />
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/sb-admin-2.css" />
    <link href="<?php echo base_url();?>assets/css/dataTables.bootstrap.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/css/dataTables.responsive.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/daterangepicker.css">

	<script src="<?php echo base_url();?>assets/js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo base_url();?>assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
	</script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/metisMenu.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/sb-admin-2.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/dataTables.bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/dataTables.responsive.js"></script>
	<script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
   	<script src="<?php echo base_url();?>assets/js/daterangepicker.js"></script>
	<? 	$session = $this->session->userdata('logged_in'); ?>
</head>


<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Rental Maintenance System</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <? echo $session['loginname'] ?>
                        <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="<?php echo base_url();?>cpanel/logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                	<? $groupId = $session['groupId']; ?>
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="<?php echo base_url();?>" style="color: black;"><i class="fa fa-dashboard fa-fw" style="color: black;"></i> Dashboard</a>
                        </li>
                        <? if($groupId == 2 OR $groupId == 4 OR $groupId == 1) { ?>
                        <li>
                            <a href="#" style="color: black;"><i class="fa fa-users fa-fw" style="color: black;"></i> Data Master <span class="fa arrow"></span></a>
                            <ul class="nav nav-third-level">
                            <? if($groupId == 4) { ?>
                            <li>
                                <a href="<?php echo base_url();?>sparepart" style="color: black;">Sparepart</a>
                            </li>
                            <? } else { ?>
                            <li>
                                <a href="<?php echo base_url();?>sparepart" style="color: black;">Sparepart</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url();?>kendaraan" style="color: black;">Vehicle</a>
                            </li>
                            
                            <li>
                                <a href="<?php echo base_url();?>user" style="color: black;">Users</a>
                            </li>
                            <? } ?>
                        	</ul>
                        </li>
                        <? } ?>
                        <? if($groupId != 4) { ?>
                        <li>
                            <a href="#" style="color: black;"><i class="fa fa-users fa-fw" style="color: black;"></i> Maintenance<span class="fa arrow"></span></a>
                            <ul class="nav nav-third-level">
							<? if($groupId == 3 OR $groupId == 1) { ?>
                             <li>
                             <a href="<?php echo base_url();?>services" style="color: black;">Input Maintenance</a>
                             </li>
                             <? } ?>
                             <? if($groupId == 2 OR $groupId == 1) { ?>
                              <li>
                             <a href="<?php echo base_url();?>services" style="color: black;">Check Maintenance</a>
                             </li>
                             <? } ?>
                            </ul>
                        </li>
                        <? if($groupId != 3) { ?>
                         <li>
                            <a href="#" style="color: black;"><i class="fa fa-users fa-fw" style="color: black;"></i> Report<span class="fa arrow"></span></a>
                            <ul class="nav nav-third-level">
                             <?php /*<li>
                             	<a href="<?php echo base_url();?>report/kendaraan" style="color: black;">Report Kendaraan Maintenance</a>
                             </li>*/?>
                             <li>
                             	<a href="<?php echo base_url();?>report/monthly" style="color: black;">Report Replacement</a>
                             </li>
                             <li>
                             	<a href="<?php echo base_url();?>report/services" style="color: black;">History Services</a>
                             </li>
                            </ul>
                        </li>
                        <? } } ?>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                	<div class="col-lg-12">
                        <h1 class="page-header"><?php echo $title;?></h1>
                    </div>
                    <?php echo $contents; ?>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
</body>
</html>
