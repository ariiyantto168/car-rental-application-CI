<?php
defined('BASEPATH') OR exit('No direct script access allowed');
#session_start(); //we need to call PHP's session object to access it through CI
class Cpanel extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('master_model');
        $this->load->model('trans_model');
    }

    function index()
    {
        if($this->session->userdata('logged_in'))
        {
            $session_data = $this->session->userdata('logged_in');
            $data['loginname'] = $session_data['loginname'];

            #untuk badge
            $data['jumlah'] = $this->master_model->master_3_count_all();
            $data['total'] = $this->trans_model->sum_transaksi();
            $data['list'] = $this->trans_model->top_expense();
            $data['sparelist'] = $this->trans_model->top_sparepart();
            $data['annual'] = $this->trans_model->annual_services();

            $this->template->set('title','Dashboard');
            $this->template->load('template','cpanel_view',$data);
        }
        else
        {
             //If no session, redirect to login page
             redirect('login', 'refresh');
        }
    }

    function logout()
    {
        $this->session->unset_userdata('logged_in');
        session_destroy();
        redirect('', 'refresh');
    }

}
?>