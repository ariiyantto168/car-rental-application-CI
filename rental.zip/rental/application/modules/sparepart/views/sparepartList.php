<script>
    $(document).ready(function() {
        $('#dataTables-services').DataTable({
                responsive: true
        });
    });
</script>
<div class="row">
	<div class="col-lg-12">
    	<div class="panel panel-default">
    	<div class="panel-heading"><a href="<?php echo base_url();?>sparepart">Sparepart</a> - <a href="<?php echo base_url();?>sparepart/create"><img src="<?php echo base_url();?>assets/images/new.png" alt="Create" border="0" title="Create" /></a></div>
		<div class="panel-body">
            <div class="dataTable_wrapper">
            	<table class="table table-striped table-bordered table-hover" id="dataTables-services">
            	<thead>
					<tr>
					<th>No</th>
                    <th>Sparepart Kode</th>
				    <th>Sparepart Name</th>
                    <th>Sisa Stok</th>
				    <th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $urut=1; foreach ($result->result_array() as $list) { ?>
				<tr>
					<td><?php echo $urut++ ?></td>
                    <td><?php echo $list['kode'] ?></td>
					<td><?php echo $list['nama'] ?></td>
                    <td><?php echo $list['stok_barang'] ?></td>
					<td><a href="<?php echo base_url();?>sparepart/update/<?php echo $list['id'] ?>"><img src="<?php echo base_url();?>assets/images/edit.png" alt="Edit" border="0" title="Edit" /></a> <a OnClick="return confirm('Are you delete this data?');" href="<?php echo base_url();?>sparepart/delete/<?php echo $list['id'] ?>"><img src="<?php echo base_url();?>assets/images/delete.png" alt="Delete" border="0" title="Delete" /></a></td>
				</tr>
				<?php } ?>
				</tbody>
            	</table>
            </div>
        </div>
		</div>
	</div>
</div>