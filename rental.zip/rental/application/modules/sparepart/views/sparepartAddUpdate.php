<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.ui.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.validate.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#services_form").validate({
		rules: {
			servicesName: {
				required:true
			}
		}
	});
});
</script>
<?php if ($_SERVER['PATH_INFO'] == "/sparepart/create") { ?>
<div class="col-lg-12">
<div class="panel panel-default">
	<div class="panel-heading">Add / Update</div>
	<div class="panel-body">
    <div class="row">
    	<div class="col-lg-6">
        <form method="post" id="sparepart_form" name="sparepart_form" enctype="multipart/form-data">
        <div class="form-group">
        	<label>Kode</label>
			<input id="kode" name="kode" type="text" maxlength="20" class="form-control" value="" />
        </div>
        <div class="form-group">
        	<label>Nama</label>
			<input id="name" name="name" type="text" maxlength="20" class="form-control" value="" />
        </div>
        <div class="form-group">
        	<label>Harga</label>
			<input id="harga" name="harga" type="text" maxlength="10" class="form-control" value="" />
        </div>
        <div class="form-group">
        	<label>Stok Barang</label>
			<input id="stok_barang" name="stok_barang" type="text" maxlength="5" class="form-control" value="" />
        </div>
        <div class="form-group">
        	<label>Sisa Stok</label>
			<input id="sisa_stok" name="sisa_stok" disabled readonly="readonly" type="text" maxlength="5" class="form-control" value="" />
        </div>
        <div class="form-group">
		<input type="submit" name="action" value="Save" class="btn btn-primary" />
		<input type="button" value="Cancel" class="btn btn-primary" onclick="document.location.replace('<?php echo base_url();?>sparepart');" />
        </div>
        </form>
        </div>
    </div>
    </div>
</div>                       
</div>

<?php } else { ?>

<div class="col-lg-12">
<div class="panel panel-default">
	<div class="panel-heading">Add / Update</div>
	<div class="panel-body">
    <div class="row">
    	<div class="col-lg-6">
        <form method="post" id="sparepart_form" name="sparepart_form" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<? echo $detail->id ?>" />
        <div class="form-group">
        	<label>Kode</label>
			<input id="kode" name="kode" type="text" maxlength="20" class="form-control" value="<? echo $detail->kode ?>" />
        </div>
        <div class="form-group">
        	<label>Nama</label>
			<input id="name" name="name" type="text" maxlength="20" class="form-control" value="<? echo $detail->nama ?>" />
        </div>
        <div class="form-group">
        	<label>Harga</label>
			<input id="harga" name="harga" type="text" maxlength="10" class="form-control" value="<? echo $detail->harga ?>" />
        </div>
        <div class="form-group">
        	<label>Stok Barang</label>
			<input id="stok_barang" name="stok_barang" type="text" maxlength="5" class="form-control" value="<? echo $detail->stok_barang?>" />
        </div>
        <div class="form-group">
        	<label>Sisa Stok</label>
			<input id="sisa_stok" name="sisa_stok" disabled readonly="readonly" type="text" maxlength="5" class="form-control" value="<? echo $detail->sisa_stok ?>" />
        </div>
        <div class="form-group">
		<input type="submit" name="action" value="Update" class="btn btn-primary" />
		<input type="button" value="Cancel" class="btn btn-primary" onclick="document.location.replace('<?php echo base_url();?>sparepart');" />
        </div>
        </form>
        </div>
    </div>
    </div>
</div>                       
</div>

<?php } ?>
