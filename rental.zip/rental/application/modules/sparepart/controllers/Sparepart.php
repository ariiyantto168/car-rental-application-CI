<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
Class Sparepart extends CI_Controller{
	
	private $limit = 10;
	function __construct()
	{
		parent::__construct();
        $this->load->model('master_model');
        $this->load->helper('form');
		$this->load->library('pagination');		
	}
	function index($offset=0, $order_column='id', $order_type='asc')
	{
        if($this->session->userdata('logged_in'))
        {
            if (!$offset) $offset=0;
            if (!$order_column) $order_column = 'id';
            if (!$order_type) $order_type = 'asc';

            $data['result'] = $this->master_model->master_2_get_paged_list($this->limit, $offset, $order_column, $order_type);

            $config['base_url']=site_url('sparepart/index/');
            $config['total_rows']=$this->master_model->master_2_count_all();
            //$config['per_page']=$this->limit;
            $config['uri_segment']='3';
            $this->pagination->initialize($config);
            $data['paginator']=$this->pagination->create_links();

            //table data
            $this->template->set('title','Sparepart');
            $this->template->load('cpanel/template','sparepartList',$data);
        }
        else
        {
            //If no session, redirect to login page
            redirect('login', 'refresh');
        }
	}
    function create()
    {
        $user = $this->session->userdata('logged_in');
        if($this->input->post('action')){

            $data_services = array('kode' => $this->input->post('kode'),
                'nama' => $this->input->post('name'),
                'harga' => $this->input->post('harga'),
                'stok_barang' => $this->input->post('stok_barang'));
            $this->master_model->master_2_save($data_services);

            //redirect
            redirect('sparepart/index/');
        }
        // load view
        $this->template->set('title','Sparepart :: Add Sparepart');
        $this->template->load('cpanel/template','sparepartAddUpdate');
    }
    function update($id)
    {
        $user = $this->session->userdata('logged_in');
        $data['detail'] = $this->master_model->master_2_get_by_id($id)->row();

        if($this->input->post('action')){
            $data_services = array('kode' => $this->input->post('kode'),
                'nama' => $this->input->post('name'),
                'harga' => $this->input->post('harga'),
                'stok_barang' => $this->input->post('stok_barang'));
            $this->master_model->master_2_update($id,$data_services);

            //redirect
            redirect('sparepart/index/');
        }
        // load view
        $this->template->set('title','Sparepart :: Update Sparepart');
        $this->template->load('cpanel/template','sparepartAddUpdate',$data);
    }
    function delete ($id)
    {
        $this->master_model->master_2_delete($id);
        redirect('sparepart/index/', 'refresh');
    }
}