-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2017 at 09:01 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental`
--
CREATE DATABASE IF NOT EXISTS `rental` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `rental`;

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
CREATE TABLE IF NOT EXISTS `group` (
  `groupId` int(11) NOT NULL AUTO_INCREMENT,
  `groupName` varchar(50) NOT NULL,
  PRIMARY KEY (`groupId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COMMENT='Group Users';

--
-- Truncate table before insert `group`
--

TRUNCATE TABLE `group`;
--
-- Dumping data for table `group`
--

INSERT INTO `group` (`groupId`, `groupName`) VALUES
(2, 'Manager'),
(3, 'Teknisi');

-- --------------------------------------------------------

--
-- Table structure for table `kendaraan`
--

DROP TABLE IF EXISTS `kendaraan`;
CREATE TABLE IF NOT EXISTS `kendaraan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(5) NOT NULL,
  `merk` varchar(75) NOT NULL,
  `tipe` int(11) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `nopolisi` varchar(10) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COMMENT='Vehicle';

--
-- Truncate table before insert `kendaraan`
--

TRUNCATE TABLE `kendaraan`;
--
-- Dumping data for table `kendaraan`
--

INSERT INTO `kendaraan` (`id`, `kode`, `merk`, `tipe`, `tahun`, `nopolisi`, `status`) VALUES
(2, 'B001', 'Avanza', 2, '3', 'B 1324 TRT', 2),
(3, 'B002', 'Xenia', 1, '3', 'B 8989 NTN', 1),
(4, 'B003', 'Honda City', 2, '3', 'B 1898 GBN', 2);

-- --------------------------------------------------------

--
-- Table structure for table `merk`
--

DROP TABLE IF EXISTS `merk`;
CREATE TABLE IF NOT EXISTS `merk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='merk';

--
-- Truncate table before insert `merk`
--

TRUNCATE TABLE `merk`;
--
-- Dumping data for table `merk`
--

INSERT INTO `merk` (`id`, `nama`) VALUES
(1, 'Avanza'),
(2, 'Xenia');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `services_id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_services` varchar(5) NOT NULL,
  `kendaraan_id` varchar(5) NOT NULL,
  `kilometer` decimal(10,0) NOT NULL,
  `tgl_services` date NOT NULL,
  `biaya` decimal(12,0) NOT NULL,
  `status_srv` int(1) NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `tglapproval` date DEFAULT NULL,
  `tglservices` date DEFAULT NULL,
  PRIMARY KEY (`services_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COMMENT='Services Vehicle';

--
-- Truncate table before insert `services`
--

TRUNCATE TABLE `services`;
--
-- Dumping data for table `services`
--

INSERT INTO `services` (`services_id`, `kode_services`, `kendaraan_id`, `kilometer`, `tgl_services`, `biaya`, `status_srv`, `created_by`, `tglapproval`, `tglservices`) VALUES
(1, '42183', '2', '0', '2017-10-27', '0', 2, 'admin', NULL, NULL),
(2, '78158', '2', '0', '2017-11-01', '0', 2, 'admin', NULL, NULL),
(3, '31337', '2', '0', '2017-11-01', '0', 2, 'admin', NULL, NULL),
(4, '91850', '3', '0', '2017-11-11', '0', 2, 'teknisi', NULL, NULL),
(5, '74401', '2', '6799', '2017-11-14', '0', 2, 'admin', '2017-11-14', '2017-11-14'),
(6, '89443', '2', '6799', '2017-11-14', '0', 2, 'admin', '2017-11-14', '0000-00-00'),
(7, '38146', '3', '6799', '2017-12-06', '0', 2, 'teknisi', '2017-12-06', '2017-12-06'),
(8, '95694', '3', '899', '2017-12-09', '0', 1, 'teknisi', '2017-12-09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `services_detail`
--

DROP TABLE IF EXISTS `services_detail`;
CREATE TABLE IF NOT EXISTS `services_detail` (
  `detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `services_id` int(11) NOT NULL,
  `sparepart_id` int(11) NOT NULL,
  `merk` varchar(150) NOT NULL,
  `jumlah` int(11) NOT NULL,
  PRIMARY KEY (`detail_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COMMENT='services detail item';

--
-- Truncate table before insert `services_detail`
--

TRUNCATE TABLE `services_detail`;
--
-- Dumping data for table `services_detail`
--

INSERT INTO `services_detail` (`detail_id`, `services_id`, `sparepart_id`, `merk`, `jumlah`) VALUES
(1, 1, 1, '', 2),
(2, 1, 2, '', 1),
(3, 2, 2, '', 8),
(4, 2, 3, '', 1),
(5, 3, 2, '', 2),
(6, 3, 3, '', 1),
(7, 4, 3, '', 2),
(8, 6, 2, 'Dunlop', 2),
(9, 6, 3, 'Sony', 1),
(10, 7, 2, 'Dunlop', 2),
(11, 7, 3, 'Sony', 1),
(12, 8, 2, 'Dunlop', 4);

-- --------------------------------------------------------

--
-- Table structure for table `sparepart`
--

DROP TABLE IF EXISTS `sparepart`;
CREATE TABLE IF NOT EXISTS `sparepart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(5) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` decimal(10,0) NOT NULL,
  `sisa_stok` int(11) NOT NULL,
  `stok_barang` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COMMENT='sparepart';

--
-- Truncate table before insert `sparepart`
--

TRUNCATE TABLE `sparepart`;
--
-- Dumping data for table `sparepart`
--

INSERT INTO `sparepart` (`id`, `kode`, `nama`, `harga`, `sisa_stok`, `stok_barang`) VALUES
(2, 'S001', 'Roda', '160000', 0, 14),
(3, 'S002', 'Radiator', '450000', 0, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tipe`
--

DROP TABLE IF EXISTS `tipe`;
CREATE TABLE IF NOT EXISTS `tipe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='tipe kendaraan';

--
-- Truncate table before insert `tipe`
--

TRUNCATE TABLE `tipe`;
--
-- Dumping data for table `tipe`
--

INSERT INTO `tipe` (`id`, `nama`) VALUES
(1, 'Minivan'),
(2, 'Sedan');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loginname` varchar(20) NOT NULL,
  `groupId` int(11) NOT NULL,
  `password` varchar(32) NOT NULL,
  `lastlogindate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `firstname` varchar(35) NOT NULL,
  `lastname` varchar(35) NOT NULL,
  `status` int(1) NOT NULL COMMENT '1=on,2=off',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COMMENT='users';

--
-- Truncate table before insert `users`
--

TRUNCATE TABLE `users`;
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `loginname`, `groupId`, `password`, `lastlogindate`, `firstname`, `lastname`, `status`) VALUES
(1, 'admin', 1, 'e10adc3949ba59abbe56e057f20f883e', '2017-11-17 11:07:37', '', '', 1),
(2, 'user', 2, 'e10adc3949ba59abbe56e057f20f883e', '2017-11-17 11:07:37', '', '', 1),
(3, 'user1', 3, 'e10adc3949ba59abbe56e057f20f883e', '2017-11-17 11:07:37', '0', 'user', 1),
(4, 'user2', 3, 'e10adc3949ba59abbe56e057f20f883e', '2017-12-09 07:11:55', '0', 'Sales', 1),
(5, 'teknisi', 3, 'e10adc3949ba59abbe56e057f20f883e', '2017-12-08 14:27:43', 'User', 'Teknisi 1', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
